from google.appengine.ext import ndb

# Create your models here.
